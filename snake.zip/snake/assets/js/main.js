import  {SnakeGame}  from './libraries/functions.js';

SnakeGame.start();
